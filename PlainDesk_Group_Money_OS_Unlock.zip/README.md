# Group Money OS — unlock pack

**Faceless Plain Desk** · soft-launch unlock (suggested **R149**, above Stokvel R99)

Free live demo (sample data): https://esteprinsloo101-web.github.io/group-money/

**Companion (not replacement):** Stokvel printable pack https://stofficial.gumroad.com/l/ydbgne

## What’s in this zip
- `app/` — full offline installable PWA
- `SETUP.md` — install, notifications, attest → close → Approve
- `DISCLAIMER.md` — not a bank / not NCR
- `guides/meeting-pack-export.md` — export meeting pack from live books
- `guides/committee-approve-checklist.md` — dual-control Approve checklist
- `sample/sample-import.json` — demo-shaped sample for Import practice

## Soft shop note
Stokvel R99 stays primary public CTA. Group Money is an upsell for treasurers who want attest/close/payout prep — not an X primary steal.
