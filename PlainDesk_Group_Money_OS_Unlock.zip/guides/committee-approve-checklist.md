# Committee Approve checklist (printable)

Before Approving a payout sheet:
- [ ] Roll attested for this period
- [ ] Period closed in books
- [ ] Payout figures match agreed rules / rotation
- [ ] Open disputes reviewed
- [ ] Late / outstanding members noted
- [ ] Dual control: second person reviewed figures
- [ ] Bank / cash payout will be done by humans (app does not pay)
- [ ] Approve logged in app only after real-world decision

Not financial or legal advice. Not a bank.
