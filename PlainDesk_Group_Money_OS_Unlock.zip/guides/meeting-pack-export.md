# Meeting pack export

1. Complete attest (and period close if this meeting needs closed books).
2. Open the meeting / export tools in the app.
3. **Export text pack** for paste into WhatsApp / email / print.
4. **Download JSON pack** for archive.
5. Pack content is built from **current localStorage** — export before resetting demo data.
6. Bring the pack to the meeting; humans still Approve any payout release.
